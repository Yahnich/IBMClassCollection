/**
 * 
 */
package model;

/**
 * @author bematpae
 * 
 */
public interface Business {

}
