package utilities;

public interface FixTypes {
	public String HEAD_COMPANY = "H";
	public String INVOICE_ADRESS_TYPE = "I";
	public String DELIVERY_ADRESS_TYPE = "D";
	public String INVOICE_STATUS_CONFIRMED = "C";
	public String INVOICE_STATUS_PRINTED = "P";
	public String INVOICE_STATUS_OPEN = "O";
	public String DEFAULT_INVOICE_STATUS = "O";
	public String DEFAULT_INVOICE_TYPE = "I";
	public String CREDIT_NOTE = "C";

}
